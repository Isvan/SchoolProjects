#define WIN_WIDTH 512
#define WIN_HEIGHT 512

#define IMAGE_WIDTH 5.0
#define DIFF_RAYS 50
